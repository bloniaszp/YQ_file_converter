Hi! I'm a small file meant to describe the contents of your folder. 

YouQuantified saves the data recorded from each of your devices as separate "csv" files. There is an additional file with the metadata for each device.

The data gathered from the web browser can have unreliable time synchrony or sampling rates, so be aware of its usage for research purposes. 

If you have questions or suggestions, please visit the repository at https://github.com/mindhiveproject/You-Quantified.

This folder contains the following files: md-v5-0000758_temperature1.csv, md-v5-0000758_skinconductanceresponsefrequency.csv, md-v5-0000758_ppg.csv, md-v5-0000758_electrodermalactivity.csv, md-v5-0000758_thermopile.csv, md-v5-0000758_accelerometer.csv, md-v5-0000758_gyroscope.csv, md-v5-0000758_magnetometer.csv, md-v5-0000758_interbeatinterval.csv, md-v5-0000758_heartrate.csv, md-v5-0000758_skinconductanceresponseamplitude.csv, md-v5-0000758_skinconductanceresponserisetime.csv, metadata.csv